import streamlit as st
import pandas as pd
import joblib
import os
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(page_title="Cyanobacterial Bloom Health Risk Predictor")

st.title("Predicting Health Risks of Cyanobacterial Blooms in Lakes")

# ---------- PATH SETUP ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, "best_model.pkl")
DATA_PATH = os.path.join(BASE_DIR, "data", "processed", "processed_data.csv")

# ---------- TRAIN MODEL IF NOT EXISTS ----------
if not os.path.exists(MODEL_PATH):
    os.makedirs(MODEL_DIR, exist_ok=True)

    data = pd.read_csv(DATA_PATH)
    X = data.drop("health_risk", axis=1)
    y = data["health_risk"]

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    joblib.dump(model, MODEL_PATH)
else:
    model = joblib.load(MODEL_PATH)

# ---------- UI ----------
st.markdown("Enter lake environmental and water quality parameters:")

temperature = st.number_input("Water Temperature (°C)", 0.0, 50.0, 30.0)
rainfall = st.number_input("Rainfall (mm)", 0.0, 500.0, 100.0)
chlorophyll = st.number_input("Chlorophyll-a (µg/L)", 0.0, 200.0, 40.0)
ph = st.number_input("pH", 0.0, 14.0, 7.5)
do = st.number_input("Dissolved Oxygen (mg/L)", 0.0, 15.0, 6.0)

if st.button("Predict Health Risk"):
    input_df = pd.DataFrame(
        [[temperature, rainfall, chlorophyll, ph, do]],
        columns=["temperature", "rainfall", "chlorophyll_a", "ph", "dissolved_oxygen"]
    )

    prediction = model.predict(input_df)[0]

    if prediction == 1:
        st.error("⚠️ High Health Risk: Harmful cyanobacterial bloom likely")
    else:
        st.success("✅ Low Health Risk: Conditions appear safe")